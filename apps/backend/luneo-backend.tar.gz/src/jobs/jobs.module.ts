import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bull';
import { AiGenerationWorker } from './worker';
import { PrismaModule } from '@/libs/prisma/prisma.module';
import { AiModule } from '@/modules/ai/ai.module';

@Module({
  imports: [
    PrismaModule,
    AiModule,
    BullModule.registerQueue({
      name: 'ai-generation',
    }),
  ],
  providers: [AiGenerationWorker],
  exports: [BullModule],
})
export class JobsModule {}
