import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '@/libs/prisma/prisma.service';
import { UserRole, BrandStatus } from '@prisma/client';

@Injectable()
export class BrandsService {
  constructor(private prisma: PrismaService) {}

  async create(createBrandDto: any, userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
    });

    if (user.role !== UserRole.BRAND_ADMIN && user.role !== UserRole.PLATFORM_ADMIN) {
      throw new ForbiddenException('Only brand admins can create brands');
    }

    return this.prisma.brand.create({
      data: {
        ...createBrandDto,
        users: {
          connect: { id: userId },
        },
      },
      include: {
        users: true,
      },
    });
  }

  async findOne(id: string, currentUser: any) {
    const brand = await this.prisma.brand.findUnique({
      where: { id },
      include: {
        users: true,
        products: true,
      },
    });

    if (!brand) {
      throw new NotFoundException('Brand not found');
    }

    // Check if user has access to this brand
    if (currentUser.role !== UserRole.PLATFORM_ADMIN && 
        currentUser.brandId !== id) {
      throw new ForbiddenException('Access denied to this brand');
    }

    return brand;
  }

  async update(id: string, updateBrandDto: any, currentUser: any) {
    // Check permissions
    if (currentUser.role !== UserRole.PLATFORM_ADMIN && 
        currentUser.brandId !== id) {
      throw new ForbiddenException('Access denied to this brand');
    }

    return this.prisma.brand.update({
      where: { id },
      data: updateBrandDto,
      include: {
        users: true,
      },
    });
  }

  async addWebhook(brandId: string, webhookData: any, currentUser: any) {
    // Check permissions
    if (currentUser.role !== UserRole.PLATFORM_ADMIN && 
        currentUser.brandId !== brandId) {
      throw new ForbiddenException('Access denied to this brand');
    }

    return this.prisma.webhook.create({
      data: {
        ...webhookData,
        brandId,
      },
    });
  }
}
